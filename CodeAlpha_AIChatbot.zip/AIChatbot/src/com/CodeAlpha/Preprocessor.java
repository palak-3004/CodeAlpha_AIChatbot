package com.CodeAlpha;
import java.util.*;
import java.util.regex.*;

public class Preprocessor {
    private static final Set<String> STOPWORDS = new HashSet<>(Arrays.asList(
        "a","an","the","is","are","am","i","you","he","she","it","we","they",
        "and","or","but","if","to","of","in","on","for","with","as","that","this",
        "was","were","be","been","by","at","from","my","me","your","yours","do","does","did"
    ));

    // naive tokenization: split on non-word, remove numbers, lowercase
    public static List<String> tokenize(String text) {
        if (text == null) return new ArrayList<>();
        text = text.toLowerCase();
        // keep only letters and whitespace
        text = text.replaceAll("[^a-z\\s]", " ");
        String[] parts = text.split("\\s+");
        List<String> tokens = new ArrayList<>();
        for (String p : parts) {
            if (p.length() > 0 && !STOPWORDS.contains(p)) tokens.add(p);
        }
        return tokens;
    }
}