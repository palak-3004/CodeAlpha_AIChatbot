package com.CodeAlpha;
import java.util.*;

public class TextPreprocessor {
    public static List<String> preprocess(String text) {
        text = text.toLowerCase().trim();
        text = text.replaceAll("[^a-z0-9 ]", "");
        String[] tokens = text.split("\\s+");
        return Arrays.asList(tokens);
    }
}
