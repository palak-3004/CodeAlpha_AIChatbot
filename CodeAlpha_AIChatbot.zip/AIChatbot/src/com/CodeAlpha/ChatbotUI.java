package com.CodeAlpha;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class ChatbotUI extends JFrame {
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;
    private NaiveBayesClassifier classifier = new NaiveBayesClassifier();
    private Map<String, String> responses = new HashMap<>();

    public ChatbotUI() {
        // Load dataset
        loadDataset(classifier, responses);

        // ===== GUI DESIGN =====
        setTitle("💬 AI Chatbot Assistant");
        setSize(1300, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(240, 245, 255));

        // ===== Header Panel =====
        JPanel header = new JPanel();
        header.setBackground(new Color(30, 60, 110));
        header.setPreferredSize(new Dimension(1300, 60));

        JLabel title = new JLabel("🤖 Smart Chatbot (Machine Learning + Web Search)");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        header.add(title);

        // ===== Chat Area =====
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        chatArea.setForeground(new Color(25, 25, 25));
        chatArea.setBackground(new Color(250, 250, 250));
        chatArea.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JScrollPane scroll = new JScrollPane(chatArea);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220), 2, true));
        scroll.setBackground(Color.WHITE);

        // ===== Input Panel =====
        JPanel inputPanel = new JPanel(new BorderLayout(10, 0));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        inputPanel.setBackground(new Color(240, 245, 255));

        inputField = new JTextField();
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        inputField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 2, true),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        sendButton = new JButton("  Send  ");
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 20));
        sendButton.setForeground(Color.WHITE);
        sendButton.setBackground(new Color(0, 123, 255));
        sendButton.setFocusPainted(false);
        sendButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        sendButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        sendButton.setBorder(BorderFactory.createLineBorder(new Color(0, 100, 200), 1, true));
        sendButton.setOpaque(true);

        // Hover effect
        sendButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sendButton.setBackground(new Color(0, 105, 230));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                sendButton.setBackground(new Color(0, 123, 255));
            }
        });

        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        // ===== Add Components =====
        add(header, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        // ===== Event Listeners =====
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());

        setVisible(true);
    }

    // ✅ Load dataset from CSV
    private void loadDataset(NaiveBayesClassifier classifier, Map<String, String> responses) {
        try (BufferedReader br = new BufferedReader(new FileReader("faq_dataset"))) {
            String line;
            br.readLine(); // skip header
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length == 3) {
                    String text = parts[0].trim().toLowerCase();
                    String intent = parts[1].trim().toLowerCase();
                    String response = parts[2].trim();
                    classifier.train(text, intent);
                    responses.put(intent, response);
                }
            }
            System.out.println("✅ Dataset loaded successfully.");
        } catch (Exception e) {
            System.out.println("⚠️ Error loading dataset: " + e.getMessage());
        }
    }

    // ✅ Handle message
    private void sendMessage() {
        String userText = inputField.getText().trim();
        if (userText.isEmpty()) return;

        chatArea.append("👤 You: " + userText + "\n");

        // Convert to lowercase for matching
        String cleanText = userText.toLowerCase().replaceAll("[^a-z0-9 ]", "").trim();
        String intent = classifier.predict(cleanText);
        String botResponse = responses.get(intent);

        // === Smart Java Question Matching ===
        if (botResponse == null) {
            if (cleanText.contains("java")) {
                botResponse = "Java is a high-level, class-based, object-oriented programming language used for building web, mobile, and desktop applications.";
            } else if (cleanText.contains("python")) {
                botResponse = "Python is an interpreted, high-level, dynamically typed programming language known for its simplicity and readability.";
            } else if (cleanText.contains("c++")) {
                botResponse = "C++ is an extension of C language that supports object-oriented programming features like classes, inheritance, and polymorphism.";
            } else if (cleanText.equals("c") || cleanText.contains("c language")) {
                botResponse = "C is a procedural programming language developed by Dennis Ritchie. It is known for efficiency and low-level memory control.";
            } else if (cleanText.contains("stack")) {
                botResponse = "A stack is a linear data structure that follows the LIFO (Last In First Out) principle. The last element added is the first one to be removed.";
            } else if (cleanText.contains("queue")) {
                botResponse = "A queue is a linear data structure that follows the FIFO (First In First Out) principle for inserting and deleting elements.";
            } else if (cleanText.contains("array")) {
                botResponse = "An array is a collection of elements stored at contiguous memory locations, allowing random access using an index.";
            } else if (cleanText.contains("linked list")) {
                botResponse = "A linked list is a linear data structure where elements are stored in nodes, and each node points to the next node.";
            } else if (cleanText.contains("database") || cleanText.contains("dbms")) {
                botResponse = "A Database Management System (DBMS) is software used to create, manage, and manipulate databases efficiently.";
            } else if (cleanText.contains("compiler")) {
                botResponse = "A compiler translates source code written in a high-level language into machine code that can be executed by a computer.";
            } else if (cleanText.contains("interpreter")) {
                botResponse = "An interpreter executes the program line by line and doesn’t produce an intermediate machine code file.";
            } else if (cleanText.contains("oop") || cleanText.contains("object oriented")) {
                botResponse = "OOP stands for Object-Oriented Programming, based on concepts like classes, objects, inheritance, polymorphism, and encapsulation.";
            } else if (cleanText.contains("algorithm")) {
                botResponse = "An algorithm is a step-by-step procedure or formula to solve a specific problem.";
            } else if (cleanText.contains("data structure")) {
                botResponse = "A data structure is a way of organizing and storing data efficiently for operations like searching, sorting, and updating.";
            } else if (cleanText.contains("recursion")) {
                botResponse = "Recursion is a programming technique where a function calls itself until a specific condition is met.";
            } else if (cleanText.contains("inheritance")) {
                botResponse = "Inheritance is an OOP concept where one class acquires the properties and behaviors of another class.";
            } else if (cleanText.contains("polymorphism")) {
                botResponse = "Polymorphism allows one interface to be used for different data types or methods.";
            } else if (cleanText.contains("encapsulation")) {
                botResponse = "Encapsulation is the OOP principle of bundling data and methods that operate on that data within a single unit (class).";
            } else if (cleanText.contains("abstraction")) {
                botResponse = "Abstraction hides complex implementation details and shows only essential features to the user.";
            } else if (cleanText.contains("exception")) {
                botResponse = "An exception is an event that occurs during program execution and disrupts the normal flow of instructions.";
            } else if (cleanText.contains("jvm")) {
                botResponse = "The Java Virtual Machine (JVM) is part of the Java Runtime Environment that executes Java bytecode.";
            } else if (cleanText.contains("ide")) {
                botResponse = "An IDE (Integrated Development Environment) provides tools like a code editor, compiler, and debugger for programming.";
            } else if (cleanText.contains("framework")) {
                botResponse = "A framework is a set of reusable code libraries that provide a structure for software development.";
            } else if (cleanText.contains("api")) {
                botResponse = "API stands for Application Programming Interface — a set of rules that allows different software systems to communicate.";
            } else if (cleanText.contains("software engineering")) {
                botResponse = "Software engineering is the systematic approach to developing, maintaining, and testing software efficiently.";
            } else if (cleanText.contains("operating system") || cleanText.contains("os")) {
                botResponse = "An Operating System is system software that manages computer hardware and provides services for computer programs.";
            } else if (cleanText.contains("network")) {
                botResponse = "A computer network is a group of interconnected devices that communicate and share resources.";
            }
        }



        if (botResponse != null) {
            chatArea.append("🤖 Bot: " + botResponse + "\n\n");
        } else {
            chatArea.append("🤖 Bot: Sorry, I don’t know that. Let me check online...\n\n");

            String lower = userText.toLowerCase();
            String searchURL;

            // Smart redirection logic
            if (lower.contains("java") || lower.contains("python") || lower.contains("c++") ||
                lower.contains("c ") || lower.contains("data structure") || lower.contains("algorithm") ||
                lower.contains("recursion") || lower.contains("stack") || lower.contains("queue") ||
                lower.contains("oop") || lower.contains("inheritance") || lower.contains("compiler") ||
                lower.contains("jvm")) {

                searchURL = "https://www.geeksforgeeks.org/?s=" + userText.replace(" ", "+");

            } else {
                searchURL = "https://www.google.com/search?q=" + userText.replace(" ", "+");
            }

            try {
                Desktop.getDesktop().browse(java.net.URI.create(searchURL));
            } catch (Exception e) {
                chatArea.append("Bot: Error opening browser!\n");
            }
        }

        inputField.setText("");
    }

    // ✅ Main method
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChatbotUI::new);
    }
}
