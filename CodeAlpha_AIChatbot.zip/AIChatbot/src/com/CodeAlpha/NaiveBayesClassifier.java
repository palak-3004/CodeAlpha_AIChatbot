package com.CodeAlpha;
import java.util.*;

public class NaiveBayesClassifier {
    private Map<String, Map<String, Integer>> wordCounts = new HashMap<>();
    private Map<String, Integer> intentCounts = new HashMap<>();
    private Set<String> vocabulary = new HashSet<>();

    // Train classifier
    public void train(String text, String intent) {
        List<String> words = TextPreprocessor.preprocess(text);
        intentCounts.put(intent, intentCounts.getOrDefault(intent, 0) + 1);
        wordCounts.putIfAbsent(intent, new HashMap<>());

        for (String word : words) {
            vocabulary.add(word);
            Map<String, Integer> counts = wordCounts.get(intent);
            counts.put(word, counts.getOrDefault(word, 0) + 1);
        }
    }

    // Predict intent
    public String predict(String text) {
        List<String> words = TextPreprocessor.preprocess(text);
        double bestScore = Double.NEGATIVE_INFINITY;
        String bestIntent = "unknown";

        if (intentCounts.isEmpty()) return bestIntent;

        for (String intent : intentCounts.keySet()) {
            double prior = Math.log(intentCounts.get(intent) + 1.0);
            double score = prior;
            for (String word : words) {
                int wordCount = wordCounts.get(intent).getOrDefault(word, 0);
                double likelihood = (wordCount + 1.0) / (intentCounts.get(intent) + vocabulary.size());
                score += Math.log(likelihood);
            }
            if (score > bestScore) {
                bestScore = score;
                bestIntent = intent;
            }
        }
        return bestIntent;
    }
}
