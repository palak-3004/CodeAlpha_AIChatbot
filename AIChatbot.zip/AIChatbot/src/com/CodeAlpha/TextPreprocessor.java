package com.CodeAlpha;

import java.util.*;

public class TextPreprocessor {

    // Preprocess text: lowercase, remove special chars, split words
    public static List<String> preprocess(String text) {
        if (text == null || text.isEmpty()) return new ArrayList<>();

        // 1. Lowercase
        text = text.toLowerCase().trim();

        // 2. Remove non-alphanumeric characters
        text = text.replaceAll("[^a-z0-9 ]", "");

        // 3. Split by spaces
        String[] tokens = text.split("\\s+");

        // 4. Convert to list and return
        return Arrays.asList(tokens);
    }
}