package com.CodeAlpha;

import javax.swing.*;
import javax.swing.event.HyperlinkEvent;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.regex.Pattern;
import java.awt.Desktop;

public class ChatbotUI extends JFrame {

    private JTextPane chatArea; // HTML + clickable links
    private JTextField inputField;
    private JButton sendButton;
    private NaiveBayesClassifier classifier = new NaiveBayesClassifier();
    private Map<String, String> responses = new HashMap<>();

    public ChatbotUI() {
        loadDataset(); // Load FAQ

        // ===== GUI Design =====
        setTitle("💬 AI Chatbot Assistant");
        setSize(1300, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(240, 245, 255));

        // ===== Header =====
        JPanel header = new JPanel();
        header.setBackground(new Color(30, 60, 110));
        header.setPreferredSize(new Dimension(1300, 60));
        JLabel title = new JLabel("🤖 Smart Chatbot (ML + Web Search)");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        header.add(title);
        add(header, BorderLayout.NORTH);

        // ===== Chat Area =====
        chatArea = new JTextPane();
        chatArea.setContentType("text/html"); // HTML support
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        chatArea.setBackground(new Color(250, 250, 250));
        chatArea.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        chatArea.addHyperlinkListener(e -> {
            if(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED){
                try {
                    Desktop.getDesktop().browse(e.getURL().toURI());
                } catch(Exception ex){
                    ex.printStackTrace();
                }
            }
        });

        JScrollPane scroll = new JScrollPane(chatArea);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220), 2, true));
        add(scroll, BorderLayout.CENTER);

        // ===== Input Panel =====
        JPanel inputPanel = new JPanel(new BorderLayout(10, 0));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        inputPanel.setBackground(new Color(240, 245, 255));

        inputField = new JTextField();
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        inputPanel.add(inputField, BorderLayout.CENTER);

        sendButton = new JButton("  Send  ");
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 20));
        sendButton.setForeground(Color.WHITE);
        sendButton.setBackground(new Color(0, 123, 255));
        sendButton.setFocusPainted(false);
        sendButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        sendButton.setOpaque(true);
        inputPanel.add(sendButton, BorderLayout.EAST);

        add(inputPanel, BorderLayout.SOUTH);

        // ===== Events =====
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());

        setVisible(true);
    }

    // ===== Load FAQ dataset =====
    private void loadDataset() {
        try (BufferedReader br = new BufferedReader(new FileReader("faq_dataset.csv"))) {
            String line;
            br.readLine(); // skip header
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length == 3) {
                    String text = parts[0].trim().toLowerCase();
                    String intent = parts[1].trim().toLowerCase();
                    String response = parts[2].trim();
                    classifier.train(text, intent);
                    responses.put(intent, response);
                }
            }
            System.out.println("✅ Dataset loaded successfully.");
        } catch (Exception e) {
            System.out.println("⚠ Error loading dataset: " + e.getMessage());
        }
    }

    // ===== Append message in chatArea with optional clickable link =====
    private void appendMessage(String sender, String message, String link) {
        try {
            HTMLDocument doc = (HTMLDocument) chatArea.getDocument();
            HTMLEditorKit editorKit = (HTMLEditorKit) chatArea.getEditorKit();

            String text = "<b>" + sender + ":</b> " + message;
            if(link != null){
                text += " <a href='" + link + "'>" + link + "</a>";
            }
            text += "<br><br>";

            editorKit.insertHTML(doc, doc.getLength(), text, 0, 0, null);
            chatArea.setCaretPosition(doc.getLength());
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    // ===== Send Message =====
    private void sendMessage() {
        String userText = inputField.getText().trim();
        if(userText.isEmpty()) return;

        appendMessage("You", userText, null);

        String cleanText = userText.toLowerCase().replaceAll("[^a-z0-9 ]", "").trim();
        String intent = classifier.predict(cleanText);
        String botResponse = responses.get(intent);

        // Technical keywords
        String[] technicalKeywords = {"java","python","c++","c","oop","inheritance",
                "polymorphism","encapsulation","abstraction","stack","queue","array",
                "linked list","algorithm","data structure","recursion","compiler",
                "interpreter","jvm","ide","framework","api"};

        boolean isTechnical = false;
        for(String keyword : technicalKeywords){
            if(Pattern.compile("\\b" + Pattern.quote(keyword) + "\\b").matcher(cleanText).find()){
                isTechnical = true;
                break;
            }
        }

        if(botResponse != null){
            if(isTechnical){
                String gfgURL = "https://www.geeksforgeeks.org/?s=" + userText.replace(" ", "+");
                appendMessage("Bot", botResponse, gfgURL);
            }else if(isTechnical){
                String gfgURL = "https://www.geeksforgeeks.org/?s=" + userText.replace(" ", "+");
                appendMessage("Bot", "I don’t know that. Check here:", gfgURL);
            } 
            else {
                String googleURL = "https://www.google.com/search?q=" + userText.replace(" ", "+");
                appendMessage("Bot", "I don’t know that. Check on Google:", googleURL);
            }
        } 

        inputField.setText("");
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(ChatbotUI::new);
    }
}